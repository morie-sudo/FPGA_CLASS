library verilog;
use verilog.vl_types.all;
entity s3_vlg_vec_tst is
end s3_vlg_vec_tst;
