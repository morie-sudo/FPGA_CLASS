library verilog;
use verilog.vl_types.all;
entity s3 is
    port(
        q               : out    vl_logic_vector(5 downto 0);
        a               : in     vl_logic_vector(2 downto 0);
        b               : in     vl_logic_vector(2 downto 0)
    );
end s3;
