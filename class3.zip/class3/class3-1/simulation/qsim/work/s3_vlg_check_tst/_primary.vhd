library verilog;
use verilog.vl_types.all;
entity s3_vlg_check_tst is
    port(
        q               : in     vl_logic_vector(5 downto 0);
        sampler_rx      : in     vl_logic
    );
end s3_vlg_check_tst;
