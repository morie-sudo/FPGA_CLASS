-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Full Version"

-- DATE "11/27/2026 08:41:19"

-- 
-- Device: Altera EP4CE6E22C8 Package TQFP144
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	s3 IS
    PORT (
	q : OUT std_logic_vector(5 DOWNTO 0);
	a : IN std_logic_vector(2 DOWNTO 0);
	b : IN std_logic_vector(2 DOWNTO 0)
	);
END s3;

-- Design Ports Information
-- q[5]	=>  Location: PIN_1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- q[4]	=>  Location: PIN_119,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- q[3]	=>  Location: PIN_136,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- q[2]	=>  Location: PIN_71,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- q[1]	=>  Location: PIN_49,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- q[0]	=>  Location: PIN_28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a[2]	=>  Location: PIN_24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b[1]	=>  Location: PIN_25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b[0]	=>  Location: PIN_132,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a[1]	=>  Location: PIN_10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a[0]	=>  Location: PIN_30,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b[2]	=>  Location: PIN_31,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF s3 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_q : std_logic_vector(5 DOWNTO 0);
SIGNAL ww_a : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_b : std_logic_vector(2 DOWNTO 0);
SIGNAL \q[5]~output_o\ : std_logic;
SIGNAL \q[4]~output_o\ : std_logic;
SIGNAL \q[3]~output_o\ : std_logic;
SIGNAL \q[2]~output_o\ : std_logic;
SIGNAL \q[1]~output_o\ : std_logic;
SIGNAL \q[0]~output_o\ : std_logic;
SIGNAL \a[2]~input_o\ : std_logic;
SIGNAL \b[1]~input_o\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[1][2]~combout\ : std_logic;
SIGNAL \a[1]~input_o\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\ : std_logic;
SIGNAL \b[0]~input_o\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[0][1]~combout\ : std_logic;
SIGNAL \a[0]~input_o\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[1][0]~combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~3\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~5\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6_combout\ : std_logic;
SIGNAL \b[2]~input_o\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[2][2]~combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[2][0]~combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2_combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~3\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~5\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~6_combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~4_combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~2_combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~0_combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~0_combout\ : std_logic;
SIGNAL \inst|lpm_mult_component|mult_core|decoder_node[0][0]~combout\ : std_logic;

BEGIN

q <= ww_q;
ww_a <= a;
ww_b <= b;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

-- Location: IOOBUF_X0_Y23_N2
\q[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~6_combout\,
	devoe => ww_devoe,
	o => \q[5]~output_o\);

-- Location: IOOBUF_X23_Y24_N2
\q[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~4_combout\,
	devoe => ww_devoe,
	o => \q[4]~output_o\);

-- Location: IOOBUF_X9_Y24_N9
\q[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~2_combout\,
	devoe => ww_devoe,
	o => \q[3]~output_o\);

-- Location: IOOBUF_X32_Y0_N16
\q[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~0_combout\,
	devoe => ww_devoe,
	o => \q[2]~output_o\);

-- Location: IOOBUF_X13_Y0_N16
\q[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~0_combout\,
	devoe => ww_devoe,
	o => \q[1]~output_o\);

-- Location: IOOBUF_X0_Y9_N9
\q[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|lpm_mult_component|mult_core|decoder_node[0][0]~combout\,
	devoe => ww_devoe,
	o => \q[0]~output_o\);

-- Location: IOIBUF_X0_Y11_N15
\a[2]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a(2),
	o => \a[2]~input_o\);

-- Location: IOIBUF_X0_Y11_N22
\b[1]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b(1),
	o => \b[1]~input_o\);

-- Location: LCCOMB_X11_Y15_N0
\inst|lpm_mult_component|mult_core|decoder_node[1][2]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[1][2]~combout\ = (\a[2]~input_o\ & \b[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \a[2]~input_o\,
	datac => \b[1]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[1][2]~combout\);

-- Location: IOIBUF_X0_Y18_N15
\a[1]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a(1),
	o => \a[1]~input_o\);

-- Location: LCCOMB_X11_Y15_N4
\inst|lpm_mult_component|mult_core|decoder_node[1][1]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\ = (\b[1]~input_o\ & \a[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \b[1]~input_o\,
	datad => \a[1]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\);

-- Location: IOIBUF_X13_Y24_N15
\b[0]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b(0),
	o => \b[0]~input_o\);

-- Location: LCCOMB_X11_Y15_N2
\inst|lpm_mult_component|mult_core|decoder_node[0][2]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\ = (\b[0]~input_o\ & \a[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b[0]~input_o\,
	datac => \a[2]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\);

-- Location: LCCOMB_X11_Y15_N14
\inst|lpm_mult_component|mult_core|decoder_node[0][1]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[0][1]~combout\ = (\a[1]~input_o\ & \b[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \a[1]~input_o\,
	datac => \b[0]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[0][1]~combout\);

-- Location: IOIBUF_X0_Y8_N15
\a[0]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a(0),
	o => \a[0]~input_o\);

-- Location: LCCOMB_X11_Y15_N16
\inst|lpm_mult_component|mult_core|decoder_node[1][0]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[1][0]~combout\ = (\a[0]~input_o\ & \b[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \a[0]~input_o\,
	datac => \b[1]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[1][0]~combout\);

-- Location: LCCOMB_X11_Y15_N6
\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~0_combout\ = (\inst|lpm_mult_component|mult_core|decoder_node[0][1]~combout\ & (\inst|lpm_mult_component|mult_core|decoder_node[1][0]~combout\ $ (VCC))) # 
-- (!\inst|lpm_mult_component|mult_core|decoder_node[0][1]~combout\ & (\inst|lpm_mult_component|mult_core|decoder_node[1][0]~combout\ & VCC))
-- \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\ = CARRY((\inst|lpm_mult_component|mult_core|decoder_node[0][1]~combout\ & \inst|lpm_mult_component|mult_core|decoder_node[1][0]~combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|lpm_mult_component|mult_core|decoder_node[0][1]~combout\,
	datab => \inst|lpm_mult_component|mult_core|decoder_node[1][0]~combout\,
	datad => VCC,
	combout => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~0_combout\,
	cout => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\);

-- Location: LCCOMB_X11_Y15_N8
\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2_combout\ = (\inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\ & ((\inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\ & 
-- (\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\ & VCC)) # (!\inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\ & (!\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\)))) # 
-- (!\inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\ & ((\inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\ & (!\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\)) # 
-- (!\inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\ & ((\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\) # (GND)))))
-- \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~3\ = CARRY((\inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\ & (!\inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\ & 
-- !\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\)) # (!\inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\ & ((!\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\) # 
-- (!\inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst|lpm_mult_component|mult_core|decoder_node[1][1]~combout\,
	datab => \inst|lpm_mult_component|mult_core|decoder_node[0][2]~combout\,
	datad => VCC,
	cin => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[0]~1\,
	combout => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2_combout\,
	cout => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~3\);

-- Location: LCCOMB_X11_Y15_N10
\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\ = (\inst|lpm_mult_component|mult_core|decoder_node[1][2]~combout\ & (\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~3\ $ (GND))) # 
-- (!\inst|lpm_mult_component|mult_core|decoder_node[1][2]~combout\ & (!\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~3\ & VCC))
-- \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~5\ = CARRY((\inst|lpm_mult_component|mult_core|decoder_node[1][2]~combout\ & !\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \inst|lpm_mult_component|mult_core|decoder_node[1][2]~combout\,
	datad => VCC,
	cin => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~3\,
	combout => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\,
	cout => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~5\);

-- Location: LCCOMB_X11_Y15_N12
\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6_combout\ = \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~5\,
	combout => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6_combout\);

-- Location: IOIBUF_X0_Y7_N1
\b[2]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b(2),
	o => \b[2]~input_o\);

-- Location: LCCOMB_X11_Y15_N18
\inst|lpm_mult_component|mult_core|decoder_node[2][2]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[2][2]~combout\ = (\b[2]~input_o\ & \a[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \b[2]~input_o\,
	datac => \a[2]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[2][2]~combout\);

-- Location: LCCOMB_X11_Y15_N20
\inst|lpm_mult_component|mult_core|decoder_node[2][1]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\ = (\b[2]~input_o\ & \a[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \b[2]~input_o\,
	datad => \a[1]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\);

-- Location: LCCOMB_X11_Y15_N30
\inst|lpm_mult_component|mult_core|decoder_node[2][0]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[2][0]~combout\ = (\b[2]~input_o\ & \a[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \b[2]~input_o\,
	datac => \a[0]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[2][0]~combout\);

-- Location: LCCOMB_X11_Y15_N22
\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~0_combout\ = (\inst|lpm_mult_component|mult_core|decoder_node[2][0]~combout\ & (\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2_combout\ $ 
-- (VCC))) # (!\inst|lpm_mult_component|mult_core|decoder_node[2][0]~combout\ & (\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2_combout\ & VCC))
-- \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\ = CARRY((\inst|lpm_mult_component|mult_core|decoder_node[2][0]~combout\ & \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|lpm_mult_component|mult_core|decoder_node[2][0]~combout\,
	datab => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[1]~2_combout\,
	datad => VCC,
	combout => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~0_combout\,
	cout => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\);

-- Location: LCCOMB_X11_Y15_N24
\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~2_combout\ = (\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\ & ((\inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\ & 
-- (\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\ & VCC)) # (!\inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\ & (!\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\)))) 
-- # (!\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\ & ((\inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\ & (!\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\)) # 
-- (!\inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\ & ((\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\) # (GND)))))
-- \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~3\ = CARRY((\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\ & (!\inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\ & 
-- !\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\)) # (!\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\ & 
-- ((!\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\) # (!\inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[2]~4_combout\,
	datab => \inst|lpm_mult_component|mult_core|decoder_node[2][1]~combout\,
	datad => VCC,
	cin => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~1\,
	combout => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~2_combout\,
	cout => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~3\);

-- Location: LCCOMB_X11_Y15_N26
\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~4_combout\ = ((\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6_combout\ $ (\inst|lpm_mult_component|mult_core|decoder_node[2][2]~combout\ $ 
-- (!\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~3\)))) # (GND)
-- \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~5\ = CARRY((\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6_combout\ & ((\inst|lpm_mult_component|mult_core|decoder_node[2][2]~combout\) # 
-- (!\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~3\))) # (!\inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6_combout\ & (\inst|lpm_mult_component|mult_core|decoder_node[2][2]~combout\ & 
-- !\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst|lpm_mult_component|mult_core|padder|adder[0]|auto_generated|result[3]~6_combout\,
	datab => \inst|lpm_mult_component|mult_core|decoder_node[2][2]~combout\,
	datad => VCC,
	cin => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~3\,
	combout => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~4_combout\,
	cout => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~5\);

-- Location: LCCOMB_X11_Y15_N28
\inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~6_combout\ = \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~5\,
	combout => \inst|lpm_mult_component|mult_core|padder|sub_par_add|adder[0]|auto_generated|op_1~6_combout\);

-- Location: LCCOMB_X10_Y13_N24
\inst|lpm_mult_component|mult_core|decoder_node[0][0]\ : cycloneive_lcell_comb
-- Equation(s):
-- \inst|lpm_mult_component|mult_core|decoder_node[0][0]~combout\ = (\a[0]~input_o\ & \b[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \a[0]~input_o\,
	datad => \b[0]~input_o\,
	combout => \inst|lpm_mult_component|mult_core|decoder_node[0][0]~combout\);

ww_q(5) <= \q[5]~output_o\;

ww_q(4) <= \q[4]~output_o\;

ww_q(3) <= \q[3]~output_o\;

ww_q(2) <= \q[2]~output_o\;

ww_q(1) <= \q[1]~output_o\;

ww_q(0) <= \q[0]~output_o\;
END structure;


