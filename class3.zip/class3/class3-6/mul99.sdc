# class3-6 : 99 multiplication table (LPM_ROM)
create_clock -name CLK -period 20.000 [get_ports {CLK}]
derive_pll_clocks
derive_clock_uncertainty
