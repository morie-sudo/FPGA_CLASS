# class3-6：用 LPM_ROM 实现九九乘法表

实验目的：把 0~9 的乘积（99 乘法表，共 100 个结果）预先写进片内 ROM，
用两个 4 位输入（A、B）拼成地址，直接读出乘积。整个设计**不含任何乘法器逻辑**，
乘积完全来自 ROM 里的数据表。

---

## 1. 设计思路

| 项目 | 说明 |
| --- | --- |
| 存储容量 | 256 字 × 8 位（8 位地址、8 位数据） |
| 地址构成 | `address[7:0] = {A[3:0], B[3:0]}`，即 **address = A×16 + B** |
| 存储内容 | 该地址放 `A×B`；A、B 取 0~9 的 100 个格子有值，其余 156 个地址填 0 |
| 数据位宽 | 8 位（最大乘积 9×9 = 81） |
| 时序 | 地址在时钟上升沿被 ROM 内部寄存器锁存（LPM_ADDRESS_CONTROL = registered），输出不寄存（LPM_OUTDATA = UNREGISTERED） |

例子：A = 3、B = 7 → 地址 = 3×16 + 7 = 55 = 0x37 → MIF 第 55 号字 = 21 → `D[7:0] = 8'd21`。

![电路图](class3-6_schematic.png)

## 2. 文件说明

| 文件 | 作用 |
| --- | --- |
| `mul99.qpf` / `mul99.qsf` | Quartus II 工程（Cyclone IV E，EP4CE6E22C6） |
| `mul99.bdf` | **Block Diagram 顶层电路**：3 个输入引脚 + 1 个 LPM_ROM + 1 个输出引脚 |
| `mul99.mif` | ROM 初始化文件，256 个字的乘法表（由 Excel 表 B2:K11 生成） |
| `mul99.sdc` | 时序约束（CLK 周期 20 ns，即 50 MHz） |
| `Waveform.vwf` | 波形文件，供 Quartus 的 Run Functional Simulation 生成测试平台 |
| `simulation/tb_mul99.v` | 自写测试平台：自动遍历 100 种组合并比对 `D` 与 `A×B` |
| `simulation/run_sim.bat` | 一键仿真脚本（编译仿真库 + 门级网表 + 测试平台并运行） |
| `output_files/mul99.sof` | 编译后生成的下载文件 |
| `output_files/mul99.fit.summary` | 资源占用报告 |
| `class3-6_schematic.png` | 电路图预览（与 bdf 坐标一一对应） |

## 3. 引脚（Fitter 自动分配，见 `output_files/mul99.pin`）

| 信号 | 引脚 | 方向 | 信号 | 引脚 | 方向 |
| --- | --- | --- | --- | --- | --- |
| CLK | 23 | 输入 | D[0] | 51 | 输出 |
| A[0] | 49 | 输入 | D[1] | 66 | 输出 |
| A[1] | 60 | 输入 | D[2] | 34 | 输出 |
| A[2] | 44 | 输入 | D[3] | 80 | 输出 |
| A[3] | 50 | 输入 | D[4] | 53 | 输出 |
| B[0] | 74 | 输入 | D[5] | 69 | 输出 |
| B[1] | 54 | 输入 | D[6] | 55 | 输出 |
| B[2] | 46 | 输入 | D[7] | 83 | 输出 |
| B[3] | 38 | 输入 | | | |

> 工程没有写死引脚位置（`No exact pin location assignment`），换板子时在
> Assignments → Pin Planner 里按实际电路板重新绑定即可，不影响逻辑。

## 4. 编译与仿真

**编译**：Quartus II 13.1 打开 `mul99.qpf` → Processing → Start Compilation；
或命令行（在工程目录下）：

```
quartus_map  mul99
quartus_fit  mul99
quartus_asm  mul99
quartus_sta  mul99
```

**功能仿真（Quartus 图形流程）**：Tools → Run Simulation Tool → RTL Simulation。
Quartus 会由 `Waveform.vwf` 生成 `simulation/qsim/Waveform.vwf.vt`，
再用 ModelSim 跑 `simulation/qsim/mul99.vo`。

**功能仿真（自动判卷，推荐）**：双击 `simulation\run_sim.bat`，
它会对 100 种组合逐一比较 `D` 与 `A×B`：

```
checked=100  errors=0
RESULT: PASS - all 100 products correct
```

## 5. 已验证结果

* 编译：Analysis & Synthesis、Fitter、Assembler、TimeQuest 全部 **0 error**。
* 资源：**0 个逻辑单元（LE）**、2048 个存储位（1 个 M9K）、17 个引脚
  ——乘法表完全由 ROM 实现。
* 时序：50 MHz 下时钟脉宽检查通过（最差 slack 9.37 ns）。
* 功能仿真（ModelSim，对编译后网表）：`checked=100  errors=0`。

## 6. MIF 与 Excel 表的对应关系

`99乘法表.xlsx` 的 Sheet1 中，第 1 行 B1:K1 是 0~9（乘数 b），
A2:A11 是 0~9（被乘数 a），B2:K11 就是 a×b。生成脚本逐个单元格核对了
"单元格值 == 行标 × 列标"，然后按 `address = a×16 + b` 写入 MIF：

```
	0	:	0;
	1	:	0;
	...
	55	:	21;      -- 3×7
	...
	153	:	81;      -- 9×9
```

## 7. 关于文件命名的说明

Quartus 允许顶层实体名带连字符（`class3-6`），编译、拟合都正常，但它为
Run Functional Simulation 生成的 Verilog 测试平台会写成 `class3-6 i1 (...)`，
这是非法 Verilog 标识符，ModelSim 报：

```
# ** Error: Waveform.vwf.vt(29): near "-": syntax error, unexpected '-'
# ** Error: .../vlog failed.
```

因此工程内的设计实体改名为合法的 `mul99`（与 class3-4 里 MUL77 的写法一致），
文件夹仍按作业要求叫 `class3-6`。
