@echo off
rem 一键检查 100 个乘积：编译仿真库 + 门级网表 + 测试平台，然后运行
rem 前提：qsim\mul99.vo 已存在（Quartus 的 Run Functional Simulation 会生成）
setlocal
set MS=C:\altera\13.1\modelsim_ase\win32aloem
set QLIB=C:\altera\13.1\quartus\eda\sim_lib
set HERE=%~dp0

cd /d "%HERE%qsim" || exit /b 1
copy /y "%HERE%..\mul99.mif" mul99.mif >nul

if not exist work md work
"%MS%\vlib.exe" work >nul
"%MS%\vlog.exe" -work work "%QLIB%\cycloneive_atoms.v" mul99.vo || exit /b 1
"%MS%\vlog.exe" -work work "%HERE%tb_mul99.v" || exit /b 1

"%MS%\vsim.exe" -c -quiet work.tb_mul99 -do "run -all; quit -f"
endlocal
