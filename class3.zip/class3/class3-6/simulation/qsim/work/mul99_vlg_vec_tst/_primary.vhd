library verilog;
use verilog.vl_types.all;
entity mul99_vlg_vec_tst is
end mul99_vlg_vec_tst;
