library verilog;
use verilog.vl_types.all;
entity mul99 is
    port(
        D               : out    vl_logic_vector(7 downto 0);
        CLK             : in     vl_logic;
        B               : in     vl_logic_vector(3 downto 0);
        A               : in     vl_logic_vector(3 downto 0)
    );
end mul99;
