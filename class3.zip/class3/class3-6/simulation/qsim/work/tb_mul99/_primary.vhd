library verilog;
use verilog.vl_types.all;
entity tb_mul99 is
end tb_mul99;
