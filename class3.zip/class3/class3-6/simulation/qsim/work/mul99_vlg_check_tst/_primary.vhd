library verilog;
use verilog.vl_types.all;
entity mul99_vlg_check_tst is
    port(
        D               : in     vl_logic_vector(7 downto 0);
        sampler_rx      : in     vl_logic
    );
end mul99_vlg_check_tst;
