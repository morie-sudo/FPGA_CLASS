`timescale 1 ps/1 ps
// 遍历 a,b = 0..9，逐个比较 D 与 A*B
module tb_mul99;
  reg clk = 0;
  reg [3:0] a = 0;
  reg [3:0] b = 0;
  wire [7:0] d;

  \mul99  uut (
    .A(a),
    .B(b),
    .CLK(clk),
    .D(d)
  );

  integer i, j, errs;

  initial begin
    errs = 0;
    #100;
    for (i = 0; i < 10; i = i + 1) begin
      for (j = 0; j < 10; j = j + 1) begin
        a = i[3:0];
        b = j[3:0];
        #50 clk = 1;
        #50 clk = 0;
        #50;
        if (d !== (i * j)) begin
          errs = errs + 1;
          $display("FAIL  a=%0d b=%0d  d=%0d  expected=%0d", i, j, d, i * j);
        end
      end
    end
    $display("checked=%0d  errors=%0d", 100, errs);
    if (errs == 0) $display("RESULT: PASS - all 100 products correct");
    else           $display("RESULT: FAIL");
    $finish;
  end
endmodule
