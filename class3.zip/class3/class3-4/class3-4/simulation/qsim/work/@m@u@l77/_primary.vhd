library verilog;
use verilog.vl_types.all;
entity MUL77 is
    port(
        D               : out    vl_logic_vector(7 downto 0);
        CKL             : in     vl_logic;
        B               : in     vl_logic_vector(2 downto 0);
        A               : in     vl_logic_vector(2 downto 0)
    );
end MUL77;
