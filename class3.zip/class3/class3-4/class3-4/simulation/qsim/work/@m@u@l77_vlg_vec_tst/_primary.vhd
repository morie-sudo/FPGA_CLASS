library verilog;
use verilog.vl_types.all;
entity MUL77_vlg_vec_tst is
end MUL77_vlg_vec_tst;
