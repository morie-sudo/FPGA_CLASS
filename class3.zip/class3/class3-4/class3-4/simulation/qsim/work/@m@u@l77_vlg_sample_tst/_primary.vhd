library verilog;
use verilog.vl_types.all;
entity MUL77_vlg_sample_tst is
    port(
        A               : in     vl_logic_vector(2 downto 0);
        B               : in     vl_logic_vector(2 downto 0);
        CKL             : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end MUL77_vlg_sample_tst;
