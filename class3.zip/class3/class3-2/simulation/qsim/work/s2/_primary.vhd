library verilog;
use verilog.vl_types.all;
entity s2 is
    port(
        clk20k          : out    vl_logic;
        clk25M          : in     vl_logic;
        clk100k         : out    vl_logic
    );
end s2;
