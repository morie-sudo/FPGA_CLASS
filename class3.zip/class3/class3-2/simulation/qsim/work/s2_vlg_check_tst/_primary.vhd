library verilog;
use verilog.vl_types.all;
entity s2_vlg_check_tst is
    port(
        clk20k          : in     vl_logic;
        clk100k         : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end s2_vlg_check_tst;
