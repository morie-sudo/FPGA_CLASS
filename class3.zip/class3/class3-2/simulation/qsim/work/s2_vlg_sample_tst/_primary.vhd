library verilog;
use verilog.vl_types.all;
entity s2_vlg_sample_tst is
    port(
        clk25M          : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end s2_vlg_sample_tst;
