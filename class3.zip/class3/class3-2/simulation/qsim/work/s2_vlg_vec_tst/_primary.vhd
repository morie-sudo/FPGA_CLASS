library verilog;
use verilog.vl_types.all;
entity s2_vlg_vec_tst is
end s2_vlg_vec_tst;
