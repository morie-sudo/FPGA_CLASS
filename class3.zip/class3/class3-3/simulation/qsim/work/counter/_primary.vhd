library verilog;
use verilog.vl_types.all;
entity counter is
    port(
        c               : out    vl_logic;
        clk             : in     vl_logic;
        en              : in     vl_logic;
        clr             : in     vl_logic;
        q               : out    vl_logic_vector(6 downto 0)
    );
end counter;
